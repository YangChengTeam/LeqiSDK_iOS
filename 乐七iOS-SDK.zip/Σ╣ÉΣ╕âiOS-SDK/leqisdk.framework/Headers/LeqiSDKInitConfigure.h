//
//  YC6071SDKInitConfigure.h
//  ycsdk
//
//  Created by zhangkai on 2018/1/8.
//  Copyright © 2018年 zhangkai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LeqiSDKInitConfigure : NSObject

@property (nonatomic, copy) NSString *appid;
@property (nonatomic, copy) NSString *agentid;
@property (nonatomic, copy) NSString *gameid;

@end
